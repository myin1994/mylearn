data = {
    1: {
        'title': '信息管理',
        'icon': 'fa-clipboard',
        'children': [
            {'title': '客户列表', 'url': '/customer/list/'}
        ]
    },
    2: {
        'title': '财务管理',
        'icon': 'fa-clipboard',
        'children': [
            {'title': '客户列表', 'url': '/customer/list/'}
        ]
    }
}

print(sorted(data))