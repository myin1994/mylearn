from django.test import TestCase

# Create your tests here.
#校区管理
   # 信息管理
     # 客户管理