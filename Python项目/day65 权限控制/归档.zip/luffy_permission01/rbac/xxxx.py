
# import sys
# def f1():
#     print('xxxxxxxx')
#
# md = sys.modules['__main__']
# print(md)
# md.f1()

a = []

b = {'1':a}

a.append(11)
print(b)














