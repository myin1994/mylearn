import os


basepath = os.path.dirname(os.getcwd())
userinfo_path = os.path.join(basepath,"db","userinfo.txt")
loginfo_path = os.path.join(basepath,"loginfo","userinfo.txt")
comment_path = os.path.join(basepath,"db","usercomment.txt")
diary_path = os.path.join(basepath,"db","userdiary")