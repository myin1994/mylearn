import os

basepath = os.path.dirname(os.getcwd())
userinfo2_path = os.path.join(basepath,"db","userinfo.bak")