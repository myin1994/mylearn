import os
BASE_PATH = os.path.dirname(os.getcwd())
userinfo_PATH = os.path.join(BASE_PATH,'db','userinfo.txt')
userlog_PATH = os.path.join(BASE_PATH,'log','userlog.txt')
userlog2_PATH = os.path.join(BASE_PATH,'log','userlog2.txt')
userlog3_PATH = os.path.join(BASE_PATH,'log','userlog3.txt')