# banner-rain-falls
纯图片+js写的雨滴掉落效果，微复古，可做banner

#如有帮助，谢谢star

 
效果图 ：


<img src="img/guyubanner.gif" />
<img src="img/guyubanner.jpg" />

 
原地址 腾讯：http://gy.qq.com/
